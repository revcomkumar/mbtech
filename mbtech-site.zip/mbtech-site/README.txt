MBtech website redesign: static site
====================================

Upload the CONTENTS of this folder to your web root (for example public_html/),
keeping the structure below. Pages refer to images with relative paths
(images/...), so the images folder must sit next to the HTML files.

  index.html            Home
  offerings.html        Our Offerings
  who-we-are.html       Who We Are
  clients.html          Our Clients
  contact.html          Contact Us
  images/
    mbtech-logo.png     Header and footer logo
    clients/            The 15 client logos (one PNG per client)

To change a logo, replace the file in images/ and keep the same file name.

Notes
- Fonts (Source Serif 4, Inter, JetBrains Mono) load from Google Fonts.
- The Testimonials page is not built yet. The "Testimonials" menu link goes to
  the testimonials section on the home page (index.html#testimonials).
- The contact form opens the visitor's email app or WhatsApp with the message
  filled in. It does not store enquiries on the server.
- If you use the old .php addresses, add redirects (for example
  who-we-are.php -> who-we-are.html) so existing links keep working.
